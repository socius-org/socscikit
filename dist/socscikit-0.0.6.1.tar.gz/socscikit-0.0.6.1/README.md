# socscikit: Social Scientist's Toolkit 

<img width="1080" alt="soscikit_icon" src="https://github.com/socius-org/socscikit/assets/130935698/090d4d76-b628-4056-8031-f5784191ce92">
