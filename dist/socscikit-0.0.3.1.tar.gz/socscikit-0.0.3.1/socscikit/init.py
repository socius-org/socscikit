import os 
import pickle

SCRIPT_DIRECTORY  = os.path.dirname(os.path.abspath(__file__))